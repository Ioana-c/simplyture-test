﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SimplytureV2.Models;

namespace SimplytureV2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CodeController : ControllerBase
    {
        private readonly CodeContext _context;

        public CodeController(CodeContext context)
        {
            _context = context;

            if (_context.Codes.Count() == 0)
            {
                _context.Codes.Add(new Code
                {
                    ReturnCode = "taskpromo"
                });

                _context.SaveChanges();
;
            }
        }

        // GET: api/code
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Code>>> GetCodes()
        {
            return await _context.Codes.ToListAsync();
        }

        // GET api/code/1
        [HttpGet("{id}")]
        public async Task<ActionResult<Code>> GetCode(int id)
        {
            var item = await _context.Codes.FindAsync(id);

            if(item == null)
            {
                return NotFound();
            }

            return item;
        }
    }
}
