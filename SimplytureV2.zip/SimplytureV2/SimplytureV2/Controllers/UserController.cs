﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SimplytureV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimplytureV2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserContext _context;

        public UserController(UserContext context)
        {
            _context = context;

            if (_context.Users.Count() == 0)
            {
                DateTime datetime = DateTime.Now;
                DateTime datetime2 = datetime.AddHours(4);
                string s1 = datetime.ToString("dd/MM/yyyy/hh:mm");
                string s2 = datetime2.ToString("dd/MM/yyyy/hh:mm");

                _context.Users.Add(new User
                {
                    ParkingTransactionID = 1234,
                    BusinessUserID = 1,
                    CarParkName = "Simplycity Park",
                    CheckInTime = s1,
                    CheckOutTime = null,
                    Invoice = 0
                });
                _context.SaveChanges();
            }
        }

        //GET: api/user
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            return await _context.Users.ToListAsync();
        }


        //GET: api/user/1
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            var item = await _context.Users.FindAsync(id);

            if(item == null)
            {
                return NotFound();
            }

            return item;
        }


    }
}
