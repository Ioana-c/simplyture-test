﻿const uri = "../api/user";
const uri2 = "../api/code";
let users = null;
let codes = null;

let status = null;

$(document).ready(function () {
    getData();
});

function getData() {
    $.ajax({
        type: "GET",
        url: uri,
        cache: false,
        success: function (data , textStatus, xhr) {
            users = data;
            status = xhr.status;
        }
    });

    $.ajax({
        type: "GET",
        url: uri2,
        cache: false,
        success: function (data, textStatus, xhr) {
            codes = data;
            status = xhr.status;
        }
    });

    $("#redeem").click( function () {
        var input, filter, i, txtValue;

        input = document.getElementById("myInput");
        filter = input.value.toLowerCase();

        console.log(filter);

        $.each(codes, function (key, item) {
            txtValue = item.returnCode;

            console.log(txtValue);

            if (txtValue.toLowerCase().indexOf(filter) > -1) {

                window.location.href = "success.html";
            }
            else {
                window.location.href = "error.html";
            }
        });

    });
};

function change() {
    var element = document.getElementById("myDIV");
    element.classList.toggle("light");
};