﻿using Microsoft.EntityFrameworkCore;

namespace SimplytureV2.Models
{
    public class CodeContext : DbContext
    {

        public CodeContext( DbContextOptions<CodeContext> options):base(options)
        {
        }

        public DbSet<Code> Codes { get; set; }
    }
}
