﻿using System;

namespace SimplytureV2.Models
{
    public class User
    {
        public int Id { get; set; }
        public int ParkingTransactionID { get; set; }
        public int BusinessUserID { get; set; }
        public string CarParkName { get; set; }
        public string CheckInTime { get; set; }
        public string CheckOutTime { get; set; }
        public int Invoice { get; set; }
    }
}
