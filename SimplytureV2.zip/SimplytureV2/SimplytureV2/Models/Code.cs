﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimplytureV2.Models
{
    public class Code
    {
        public int Id { get; set; }
        public string ReturnCode { get; set; }
    }
}
