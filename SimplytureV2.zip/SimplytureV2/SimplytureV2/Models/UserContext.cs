﻿using Microsoft.EntityFrameworkCore;

namespace SimplytureV2.Models
{
    public class UserContext : DbContext
    {
        public UserContext( DbContextOptions<UserContext> options):base(options)
        {
        }

        public DbSet<User> Users { get; set; }
    }
}
