﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Serialization.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Simplyture
{
    public class Program
    {
        private static readonly HttpClient client = new HttpClient();

        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();

            var repositories = ProcessRepositories().Result;

            foreach (var repo in repositories) {
                Console.WriteLine(repo.BusinessUserID);
            Console.WriteLine(repo.RegistrationNumber);
            }
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>();

        private static async Task<List<Repository>> ProcessRepositories()
        {

            var serializer = new DataContractJsonSerializer(typeof(List<Repository>));

            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Add("Authorization", "Basic MTQyOkJGNjhGQjMzLTQxQTItNDkxRS04MzMwLTY1NDcyMTU2RkZGMQ==");

            var streamTask = client.GetStreamAsync("http://reststaging.simplyture.com/api/v1/PromoCodeRedeem?BusinessUserID=BUSINESS_USER_ID");

            var repositories = serializer.ReadObject(await streamTask) as List<Repository>;
            return repositories;


        }
    }
}
