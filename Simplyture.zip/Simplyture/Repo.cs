﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Simplyture
{
    [DataContract(Name = "Repo")]
    public class Repository
    {
        [DataMember(Name = "BusinessUserID")]
        public string BusinessUserID { get; set; }

        [DataMember(Name = "RegistrationNumber")]
        public string RegistrationNumber { get; set; }
    }

}
